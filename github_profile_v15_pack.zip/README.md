<!-- Adapted layout: animated SVG panels for every section. -->
<p align="center">
  <img src="./assets/hero.svg?v=1" width="100%" alt="Hi, I'm Tanmoy Majumder, builder at GDL Technologies. I build a programming language, Android apps and AI tools, in public." />
</p>

<img src="./assets/about-life.svg?v=1" width="100%" alt="Programming languages, Android and AI apps, building in public. Beyond work: making reels, voice experiments, and open source." />

<img src="./assets/stack.svg?v=1" width="100%" alt="My stack: Rust, TypeScript, Python, React, Next.js, Three.js, Kotlin, Tauri, and LLM APIs, plus JavaScript, Node.js, Flutter, Jetpack Compose, WebGL, GLSL, Tailwind CSS, SQL, Linux, Framer Motion, WebAssembly and Git." />

### Things I've built

| Project | What it does | Focus |
| :--- | :--- | :--- |
| [**TechScript**](https://github.com/Tcode-Motion/techscript) | Plain English programming language with a native Rust compiler, WebForge and AppForge. Also on [PyPI](https://pypi.org/project/techscript-lang/) | Language + Systems |
| [**NovOS**](https://github.com/Tcode-Motion/NovOS) | Cinematic browser operating system with 40 plus built-in apps and the Nova AI assistant. [Live demo](https://tcode-motion.github.io/NovOS/) | Web Experience |
| [**KinotiX**](https://github.com/Tcode-Motion/KinotiX) | 4K live and 3D wallpaper app, live on Google Play | Android |
| [**Satvora&nbsp;AI**](https://github.com/Tcode-Motion/Satvora-AI) | AI food intelligence for Indian lifestyles | AI + Health |
| [**Vortyx**](https://github.com/Tcode-Motion/Vortyx) | Android media downloader and download manager, Material 3 UI | Android |
| [**WallVault**](https://github.com/Tcode-Motion/os-wallpapers) | 600 plus curated OS wallpapers across 14 categories, instant search | Tauri + React |
| [**MiniVibe&nbsp;Music**](https://github.com/Tcode-Motion/MiniVibe) | Offline music player with EQ and lyrics | Android |
| VoiceForge | Clone your own voice on your own computer, fully offline | Python + AI |
| [**Computer&nbsp;Part&nbsp;Map**](https://github.com/Tcode-Motion/computer-part-map) | Interactive hardware encyclopedia with 70 plus pages and visual component explorer | Web |
| [**Arc&nbsp;Reactor&nbsp;3D**](https://github.com/Tcode-Motion/arc-reactor-3d) | Scroll-driven Iron Man Arc Reactor with HUD overlays | 3D Web |
| [**Solar&nbsp;System&nbsp;3D**](https://github.com/Tcode-Motion/solar-system) | Interactive 3D solar system with orbital mechanics and WebGL lighting | 3D Web |
| [**AR&nbsp;Keyboard**](https://github.com/Tcode-Motion/AR-Keyboard) | Augmented reality virtual keyboard that runs in any smartphone browser | AR + Web |

<img src="./assets/id-dashboard.svg?v=1" width="100%" alt="Tanmoy's builder ID and public dashboard. 24 public repositories, 86 received repo stars, 10 followers. Snapshot: November 9, 2026." />

<img src="./assets/skills.svg?v=1" width="100%" alt="Skills at a glance: JavaScript and TypeScript expert, Three.js and 3D web expert, HTML, CSS and Tailwind expert, React, Next.js, Python, Node.js, Kotlin, Jetpack Compose, WebGL and GLSL advanced, Rust, Egui, Tauri and Linux proficient." />

<img src="./assets/techscript.svg?v=1" width="100%" alt="TechScript spotlight: a plain English programming language with a native Rust VM, TechScript Studio IDE, 150 plus built-ins, a web builder, a 3D module and one installer." />

<p align="center">
  <a href="https://github.com/Tcode-Motion/techscript/releases/latest">Download TechScript</a> &nbsp;·&nbsp;
  <a href="https://pypi.org/project/techscript-lang/">pip install techscript-lang</a> &nbsp;·&nbsp;
  <a href="https://techscript.is-a.dev">TechScript Docs</a>
</p>

<img src="./assets/about.svg?v=1" width="100%" alt="About Tanmoy: independent software developer and open-source builder from West Bengal, India, creator of TechScript, working across 3D web, browser operating systems and Android apps." />

<img src="./assets/buildvision.svg?v=1" width="100%" alt="How I build: idea, prompt, build, ship, with Claude, Cursor, Claude Code, Copilot, v0, Bolt.new and Google AI Studio for code, and Veo, Sora and Kling AI for video. Vision: languages anyone can read, the web in 3D, operating systems in the browser, handcrafted Android apps, projects from the future." />

<img src="./assets/connect.svg?v=1" width="100%" alt="Let's build what's next. Connect on LinkedIn, watch T Code Motion on YouTube, follow @tcodemotion on Instagram, or find the code on GitHub using the links below." />

<p align="center">
  <a href="https://www.linkedin.com/in/tanmoy-majumder-/">LinkedIn</a> &nbsp;·&nbsp;
  <a href="https://www.youtube.com/@tcodemotion">YouTube: T Code Motion</a> &nbsp;·&nbsp;
  <a href="https://www.instagram.com/tcodemotion/">Instagram: @tcodemotion</a> &nbsp;·&nbsp;
  <a href="https://x.com/TanmoyMaju40558">X: @TanmoyMaju40558</a> &nbsp;·&nbsp;
  <a href="https://github.com/Tcode-Motion">GitHub: Tcode-Motion</a>
</p>

<p align="center">
  <a href="https://tanmoy.is-a.dev/">Portfolio</a> &nbsp;·&nbsp;
  <a href="https://techscript.is-a.dev">TechScript Docs</a> &nbsp;·&nbsp;
  <a href="https://tcode-motion.github.io/NovOS/">NovOS Live Demo</a> &nbsp;·&nbsp;
  <a href="mailto:majumdertanmoy510@gmail.com">majumdertanmoy510@gmail.com</a>
</p>

<p align="center"><b>One Step Ahead. Always.</b></p>

<p align="center"><sub>Write like a human. Build in public.</sub></p>
